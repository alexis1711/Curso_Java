package personas;

public class Persona5 {
    private String nombre;
    private int idPersona;
    private static int contadorPersonas;

    public Persona5(String nombre){
        contadorPersonas++;
        idPersona = contadorPersonas;
        this.nombre = nombre;
    }

    @Override
    public String toString() {
        return "Persona5{" +
                "nombre='" + this.nombre +
                ", idPersona=" + this.idPersona +
                '}';
    }
    public static int getContadorPersonas(){
        return contadorPersonas;
    }
}
