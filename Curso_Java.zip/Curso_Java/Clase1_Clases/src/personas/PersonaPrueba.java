package personas;

public class PersonaPrueba {
    public static void main(String[] args) {
        /*
        Corrida de clase Persona
        //Creación de un objeto
        Persona p1 = new Persona();

        //Llamando a un método del objeto creado
        System.out.println("Valores por default del objeto Persona");
        p1.desplegarNombre();

        //Modificar valores
        p1.nombre = "Juan";
        p1.apellidoPaterno = "Esparza";
        p1.apellidoMaterno = "Lara";

        //Volvemos a llamar al método
        System.out.println("\nNuevos valores del objeto Persona");
        p1.desplegarNombre();

         */
        /*
        //Variables locales
        int operandoA = 6;
        int operandoB = 2;

        //Creamos un objeto de aritmetica
        Aritmetica obj1 = new Aritmetica(operandoA, operandoB);

        //Imprimir operandos
        System.out.println("Operando A: " + operandoA + " y Operando B: " + operandoB);

        //Imprimir operaciones
        System.out.println("\nSuma: " + obj1.sumar());
        System.out.println("\nResta: " + obj1.restar());
        System.out.println("\nMuliplicación: " + obj1.multiplicar());
        System.out.println("\nDivisión: " + obj1.dividir());


    }
    /*
    void otroMetodo(){
        //No se puede acceder a una variable local declarada en otro metodo
        //(operando está declarada en el metodo main)
        System.out.println("valor operando A: "+ operandoA);
        }
     */
/*
        Persona2 p = new Persona2();
        p.cambiarNombre("Juan");
        imprimirNombre(p);
        modificarPersona(p);
        imprimirNombre(p);
    }
    public static void modificarPersona(Persona2 arg){
        arg.cambiarNombre("Carlos");
    }
    public static void imprimirNombre(Persona2 p){
        System.out.println("Valor recibido: "+ p.obtenerNombre());
    }

 *//*
        int x = 10;
        imprimir(x);
        cambiarValor(x);
        imprimir(x);
    }
    public static void cambiarValor(int i){
        i = 200;
    }
    public static void imprimir(int arg){
        System.out.println("Valor recibido: " + arg);
    }
    */
        Persona5 p5 = new Persona5("Juan");
        System.out.println("Persona 1: " + p5);

        Persona5 p4 = new Persona5("Karla");
        System.out.println("Persona 2: " + p4);

        System.out.println("No. Personas: " + Persona5.getContadorPersonas());

    }
}

