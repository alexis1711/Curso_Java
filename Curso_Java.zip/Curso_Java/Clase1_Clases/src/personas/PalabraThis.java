package personas;

public class PalabraThis {
    public static void main(String[] args) {
        Persona3 p = new Persona3("Juan");
    }
}
class Persona3{
    String nombre;
    Persona3(String nombre) {
        this.nombre = nombre;

        Imprimir i = new Imprimir();
        i.imprimir(this);
    }
}
class Imprimir{
    public void imprimir(Object o){
        System.out.println("Imprimir parametro: " + o);
        System.out.println("Imprimir objeto actual (this): " + this);
    }
}
