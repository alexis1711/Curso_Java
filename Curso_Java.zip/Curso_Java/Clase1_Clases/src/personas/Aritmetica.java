package personas;

public class Aritmetica {
    int a;
    int b;

    //Constructor Vacio
    //Recordar que si agregamos un constructor con parametros
    //El constructor vacio ya no se crea automaticamente y debemos crearlo manual

    Aritmetica(){

    }

    Aritmetica(int a, int b){
        this.a = a;
        this.b = b;
    }

    //Estos metodos toman los atributos de la clase para hacer la operación
    int sumar(){
        return a + b;
    }
    int restar(){
        return a - b;
    }
    int multiplicar(){
        return a * b;
    }
    int dividir(){
        return a / b;
    }
}
