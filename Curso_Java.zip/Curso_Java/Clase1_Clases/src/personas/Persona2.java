package personas;

public class Persona2 {
    String nombre;
    public void cambiarNombre(String nuevoNombre) {
        this.nombre = nuevoNombre;
    }
    public String obtenerNombre() {
        return nombre;
    }
}
