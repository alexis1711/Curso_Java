package personas;

public class PalabraNull {
    public static void main(String[] args) {
        Persona4 p4 = new Persona4("Juan");
        p4.obtenerNombre();
    }
}
class Persona4{
    private String nombre;
    public Persona4(String nombre){
        this.nombre = nombre;
    }
    public String obtenerNombre(){
        return this.nombre;
    }
}
