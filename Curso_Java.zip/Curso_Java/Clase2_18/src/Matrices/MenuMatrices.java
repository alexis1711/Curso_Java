package Matrices;

public class MenuMatrices {
    public static void main(String[] args) {
        //Declaramos e instanciamos una matriz de personas
        PersonaM personas [][] = new PersonaM[3][2];

        //Inicializamos los valores de la matriz de personas
        personas[0][0] = new PersonaM("Juan");
        personas[0][1] = new PersonaM("Armando");
        personas[1][0] = new PersonaM("Karla");
        personas[1][1] = new PersonaM("Laura");
        personas[2][0] = new PersonaM("Pedro");
        personas[2][1] = new PersonaM("Javier");

        //Leemos valores de cada elemento de la matriz con un ciclo for anidado
        System.out.println("");
        for (int i = 0; i < personas.length; i++){
            for(int j = 0; j < personas[i].length; j++){
                System.out.println("Personas[" + i + "]" + "[" + j + "] = " + personas[i][j] );
            }
        }

    }
}
