package Test;

import Herencia.*;

import java.util.Date;

public class TestHerencia {
    public static void main(String[] args) {
        Empleado empleado1 = new Empleado("Juan Campos",1200);
        empleado1.setGenero('M');
        empleado1.setDireccion("San Martin");
        empleado1.setEdad(25);
        System.out.println(empleado1.obtenerDetalle());

        var fecha = new Date();
        Cliente cliente1 = new Cliente(new Date(), true, "Alfonso", 'M',
                26, "Santa Ana");

        System.out.println(cliente1.obtenerDetalle());

        imprimir(cliente1);


        //COMO DECLARAR ARREGLOS

        // tipo [] nombreArreglo; ó tipo nombreArreglo [];
        // Persona [] personas; ó Persona personas [];


        //COMO INSTANCIAR ARREGLOS

        // nombreArreglo = new tipo[largo];
        // personas = new Persona[13];


        //INICIALIZAR ELEMENTOS DE UN ARREGLO

        //nombreArreglo[indice] = valor;
        //personas[0] = new Persona("Pedro", "Lara");


        //EXTRAER ELEMENTOS DE UN ARREGLO

        //Persona p = personas[0];



    }

    public static void imprimir(Persona persona){
        System.out.println(persona.obtenerDetalle());
    }
}
