package Test;

import Herencia.*;

public class EjemploArreglos {
    public static void main(String[] args) {
        //Tipo Int

        //Declaramos un arreglo de enteros
        int edades[];

        //Instanciamos el arreglo de enteros
        edades = new int[3];

        //Inicializamos los valores del arreglo de enteros
        edades[0] = 30;
        edades[1]= 15;
        edades[2] = 20;

        //Imprimimos los valores del arreglo de enteros
        //Leemos los valores de cada elemento del arreglo
        System.out.println("Arreglo enteros indice 0: " + edades[0]);
        System.out.println("Arreglo enteros indice 1: " + edades[1]);
        System.out.println("Arreglo enteros indice 2: " + edades[2]);

        //Tipo Persona

        //Declaramos un arreglo de personas
        Persona personas[];

        //Instanciamos el arreglo de personas
        personas = new Persona[4];

        //Inicializamos los valores del arreglo de personas
        personas[0] = new Persona("Juan");
        personas[1] = new Persona("Karla");
        personas[2] = new Persona("Carlos");

        //Tipo String

        //Arreglo de String, notación simplificada
        String nombres[] = {"Sara", "Laura", "Carlos", "Carmen"};
        int i = 0;
        for (String sr:nombres) {
            System.out.println("Arreglo String indice[" + i + "]: " + sr );
            i++;
        }
    }
}
