package ManejoExcepciones;

import datos.metodos;
import excepciones.NumerosExcepcion;

public class Manejo {
    public static void main(String[] args) {

    }

    private static void ejecutar(metodos m, int a, int b, String accion){
        if("sumar".equals(accion)){
            try{
                m.sumar(a,b);
            }catch(NumerosExcepcion ex){
                System.out.println("Error, digite numeros enteros");
            }finally{
                System.out.println("Termino el analisis");
            }

        }
    }
}
