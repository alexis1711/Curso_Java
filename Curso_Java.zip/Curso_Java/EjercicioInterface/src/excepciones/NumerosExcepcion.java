package excepciones;

public class NumerosExcepcion extends DatosExcepcion{
    public NumerosExcepcion(String mensaje){
        super(mensaje);
    }
}
