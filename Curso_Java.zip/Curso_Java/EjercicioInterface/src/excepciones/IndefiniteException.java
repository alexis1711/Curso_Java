package excepciones;

public class IndefiniteException extends DatosExcepcion{
    public IndefiniteException(String mensaje){
        super(mensaje);
    }
}
