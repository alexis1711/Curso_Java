package excepciones;

public class DatosExcepcion extends Exception{
    public DatosExcepcion(String mensaje){
        super(mensaje);
    }
}
