package excepciones;

public class DecimalException extends DatosExcepcion{
    public DecimalException(String mensaje){
        super(mensaje);
    }
}
