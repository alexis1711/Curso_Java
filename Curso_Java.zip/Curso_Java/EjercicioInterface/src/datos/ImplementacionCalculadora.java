package datos;

import excepciones.DatosExcepcion;

public class ImplementacionCalculadora implements metodos{
    @Override
    public void sumar(int a, int b) throws DatosExcepcion {
        int suma = a + b;
        System.out.println("La suma es: " + suma);
    }

    @Override
    public void restar(int a, int b) {
        int resta = a - b;
        System.out.println("La resta es: " + resta);
    }

    @Override
    public void multiplicar(int a, int b) {
        int multiplicacion = a * b;
        System.out.println("La multiplicacion es: " + multiplicacion);
    }

    @Override
    public void dividir(int a, int b) {
        float division = (a / b);
        System.out.println("La division es: " + division);
    }
}
