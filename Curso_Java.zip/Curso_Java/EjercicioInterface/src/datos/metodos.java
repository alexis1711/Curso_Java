package datos;

import excepciones.DatosExcepcion;

public interface metodos {
    void sumar(int a, int b) throws DatosExcepcion;
    void restar(int a, int b) throws DatosExcepcion;
    void multiplicar(int a, int b) throws DatosExcepcion;
    void dividir(int a, int b)throws DatosExcepcion;
}
