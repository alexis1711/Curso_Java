package mundopc;

import com.gm.mundopc.*;

public class MundoPC {

    public static void main(String[] args){

        //Creacion computadora Toshiba
        Monitor monitorToshiba = new Monitor("Toshiba", 11);
        Teclado tecladoToshiba = new Teclado("bluetooth", "Toshiba");
        Raton ratonToshiba = new Raton("bluetooth", "toshiba");
        Computadora compuToshiba = new Computadora("Computadora toshiba", monitorToshiba, tecladoToshiba, ratonToshiba);

        //Creacion computadora Dell
        Monitor monitorDell = new Monitor("Dell", 11);
        Teclado tecladoDell = new Teclado("bluetooth", "Dell");
        Raton ratonDell = new Raton("bluetooth", "Dell");
        Computadora compuDell = new Computadora("Computadora Dell", monitorDell, tecladoDell, ratonDell);

        Orden orden1 = new Orden();
        orden1.agregarComputadora(compuToshiba);
        orden1.agregarComputadora(compuDell);

        orden1.mostrarOrden();

        Orden orden2 = new Orden();
        orden2.agregarComputadora(compuToshiba);
        orden2.agregarComputadora(compuDell);

        orden2.mostrarOrden();
    }


}
