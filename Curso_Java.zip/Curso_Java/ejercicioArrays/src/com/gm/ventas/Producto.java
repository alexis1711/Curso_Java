package com.gm.ventas;

public class Producto {

    //Atributos de la clase
    private final int idProducto;
    private String nombre;
    private double precio;
    private static int contadorProducto = 1;

    //Constructor sin parametros privado
    private Producto() {
        this.idProducto = contadorProducto++;
    }

    //Constructor con parametros
    public Producto(String nombre, double precio) {
        this();
        this.nombre = nombre;
        this.precio = precio;
    }

    //Propiedades Get y Set para acceder a los atributos
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    //Metodo toString
    @Override
    public String toString() {
        return "Producto{" +
                "idProducto=" + idProducto +
                ", nombre='" + nombre +
                ", precio=" + precio +
                '}';
    }
}
