package com.gm.ventas;

import java.text.DecimalFormat;

public class Orden {

    //Atributos de la clase
    private final int idOrden;
    private Producto productos[];
    private int limite = 2;
    private static int contadorOrden = 1;
    private static int contadorProducto = 0;

    //Constructor
    public Orden(){
        this.idOrden = ++contadorOrden;
        productos = new Producto[limite];
    }

    //Metodo para agregar productos al array
    public void agregarProducto(Producto producto){
        if(contadorProducto >= limite){
            System.out.println("El array está lleno...");
        }
        else {
            boolean bandera2 = false;
            int i = 0;
            do{
                Producto c = productos[i];
                if(c == null){
                    productos[i] = producto;
                    System.out.println("Producto agregado correctamente... ");
                    bandera2 = true;
                    contadorProducto++;
                }
                else {
                    i++;
                }
            }while(bandera2 == false);
        }

    }

    //Metodo para calcular el total de una orden
    public double calcularTotal(){
        double total = 0;
        for (Producto p: productos){
            total += p.getPrecio();
        }

        return Math.round(total*100.0)/100.0;
    }

    //Metodo para mostrar los productos de una orden que estan guardados en array
    public void mostrarLista() {
        int i = 1;
        for(Producto p: productos) {
            System.out.println("Producto " + i + ": " + p);
            i++;
        }
    }
}
