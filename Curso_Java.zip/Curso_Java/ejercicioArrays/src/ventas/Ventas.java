package ventas;

import com.gm.ventas.*;
public class Ventas {
    public static void main(String[] args) {

        //Creacion de productos
        Producto p1 = new Producto("Jabon", 1.25);
        Producto p2 = new Producto("Cilantro", 0.68);
        Producto p3 = new Producto("Carrito", 2.35);

        //Creacion de orden y añadidos de productos
        Orden o1 = new Orden();
        o1.agregarProducto(p1);
        o1.agregarProducto(p2);
        o1.agregarProducto(p3);

        //Impresion del total de la orden y los detalles
        System.out.println(o1.calcularTotal());
        o1.mostrarLista();

    }
}
