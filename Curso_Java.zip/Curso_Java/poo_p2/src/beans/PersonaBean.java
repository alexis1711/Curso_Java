package beans;

import java.io.Serializable;

public class PersonaBean implements Serializable{
    //Cada propiedad private
    private String nombre;
    private int edad;

    //Constructor vacio
    public PersonaBean(){

    }

    //Constructor del JavaBean (no requerido)
    public PersonaBean(String nombre, int edad){
        this.nombre = nombre;
        this.edad = edad;
    }

    //Get y Set de cada propiedad (Según se requiera)

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
}
