package manejoexcepciones1;

import domain.Division;
import domain.OperationException;

public class ManejoExcepcionesArg {

    public static void main(String[] args) throws OperationException {
        try{
            int op1 = Integer.parseInt(args[0]);
            int op2 = Integer.parseInt(args[1]);
            Division div = new Division(op1, op2);
            div.visualizarOperacion();
        }catch(ArrayIndexOutOfBoundsException ex){
            System.out.println("Ocurrio una excepción: ");
            System.out.println("Hubo un error al acceder un elemento fuera de");
            ex.printStackTrace();
        }catch(NumberFormatException ex){
            System.out.println("Ocurrio una excepción: ");
            System.out.println("Uno de los argumentos no es entero");
            ex.printStackTrace();
        }catch(OperationException ex){
            System.out.println("Ocurrio una excepción: ");
            System.out.println("Se trató de realizar una operación erronea");
            ex.printStackTrace();
        }finally{
            System.out.println("Se terminaron de revisar las excepciones");
        }
    }
}
