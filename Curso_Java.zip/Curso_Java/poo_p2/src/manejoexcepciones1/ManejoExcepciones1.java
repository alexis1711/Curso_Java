package manejoexcepciones1;

import domain.Division;
import domain.OperationException;

public class ManejoExcepciones1 {

    public static void main(String[] args) {
        try{
            Division div = new Division(10, 0);
            div.visualizarOperacion();
        }catch(OperationException ex){
            System.out.println("Ocurrio un error!!!");
            ex.printStackTrace();
        }
    }
}
