package excepciones;

import datos.AccesoDatos;

public class AccesoDatosEx extends Exception{
    public AccesoDatosEx(String mensaje){
        super(mensaje);
    }
}
