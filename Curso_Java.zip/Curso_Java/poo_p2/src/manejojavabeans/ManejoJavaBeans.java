package manejojavabeans;

import beans.PersonaBean;

public class ManejoJavaBeans {

    public static void main(String[] args) {
        PersonaBean pb = new PersonaBean();
        pb.setNombre("Juan");
        pb.setEdad(29);

        System.out.println("Nombre: " + pb.getNombre());
        System.out.println("Edad: " + pb.getEdad());
    }
}
