package ejemploinstanceof;

public class FiguraGeometrica {

    public void dibujar(){
        System.out.println("dibujar figura geometrica");
    }
}
