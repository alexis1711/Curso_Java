package ejemploinstanceof;

public class Triangulo extends FiguraGeometrica{
     public void dibujar(){
        System.out.println("dibujar triangulo");
    }
}
