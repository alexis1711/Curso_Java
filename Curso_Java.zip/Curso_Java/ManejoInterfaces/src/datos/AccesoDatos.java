package datos;

import excepciones.*;

public interface AccesoDatos {
    
    public abstract void insertar();
    
    public abstract void listar() ;
    
}
