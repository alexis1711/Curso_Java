package excepciones;

public class AccesoDatosEx extends Exception{
    
    public AccesoDatosEx(String mensaje){
        super(mensaje);
    }
    
}
